﻿using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using UnityEngine;

public enum ChannelType
{
    SignedShortVector4 = 0x0193,      
    SignedShortVector3 = 0x0192,    
    SignedShortVector2 = 0x0191,    
    SignedShortSingle = 0x0190,     
    SkinIndices = 0x0103,        
    VertexColor = 0x0083,        
    FloatVector4 = 0x0023,         
    FloatVector3 = 0x0022,        
    FloatVector2 = 0x0021,        
    Float = 0x0020,
    Nothing = 0xFFFF
}

public struct MeshHeader
{
    public Vector3 boundsPos;
    public Vector3 boundsSc;

    public uint vertexSize;
    public uint vertexChunkSize;
    public uint uFaceCount;
    public uint blendShapeCount;
    public uint bindPoseCount;

    public ChannelType[] channels;
    public Vertex[] vertices;
    public uint[] faces;
    public BlendShapeMeta[] metas;
    public BlendShapeData[] datas;
    public Matrix4x4[] mats;

    public MeshHeader(BinaryReader reader, GameObject root)
    {
        Vector3 size = new Vector3();
        Vector3 offset = new Vector3();

        reader.BaseStream.Seek(48, SeekOrigin.Begin);
        size.x = reader.ReadSingle();
        reader.BaseStream.Seek(52, SeekOrigin.Begin);
        size.y = reader.ReadSingle();
        reader.BaseStream.Seek(56, SeekOrigin.Begin);
        size.z = reader.ReadSingle();

        reader.BaseStream.Seek(64, SeekOrigin.Begin);
        offset.x = reader.ReadSingle();
        reader.BaseStream.Seek(68, SeekOrigin.Begin);
        offset.y = reader.ReadSingle();
        reader.BaseStream.Seek(72, SeekOrigin.Begin);
        offset.z = reader.ReadSingle();

        boundsPos = size;
        boundsSc = offset * 2;

        reader.BaseStream.Seek(88, SeekOrigin.Begin);
        bindPoseCount = reader.ReadUInt32();
        reader.BaseStream.Seek(196, SeekOrigin.Begin);
        vertexSize = reader.ReadUInt32();
        reader.BaseStream.Seek(136, SeekOrigin.Begin);
        vertexChunkSize = reader.ReadUInt32();
        reader.BaseStream.Seek(168, SeekOrigin.Begin);
        uFaceCount = reader.ReadUInt32();
        reader.BaseStream.Seek(152, SeekOrigin.Begin);
        blendShapeCount = reader.ReadUInt32();

        reader.BaseStream.Seek(234, SeekOrigin.Begin);

        channels = new ChannelType[18];

        foreach (ChannelType type in channels)
        {
            Debug.Log("channel format: " + type);
        }

        vertices = new Vertex[vertexChunkSize / vertexSize];

        faces = new uint[uFaceCount];

        for (int i = 0; i < 18; i++)
        {
            channels[i] = (ChannelType)reader.ReadUInt16();
        }

        reader.BaseStream.Seek(272, SeekOrigin.Begin);

        for (int i = 0; i < vertexChunkSize / vertexSize; i++)
        {
            vertices[i] = new Vertex(reader, channels, (int)vertexSize, (int)bindPoseCount);
        }

        reader.BaseStream.Position = (reader.BaseStream.Position + 15) & ~15;

        Debug.Log(string.Format("stream pos faces: {0}", reader.BaseStream.Position));

        for (int i = 0; i < uFaceCount; i++)
        {
            faces[i] = (uint)reader.ReadUInt16();
        }

        reader.BaseStream.Position = (reader.BaseStream.Position + 15) & ~15;

        metas = new BlendShapeMeta[blendShapeCount];
        datas = new BlendShapeData[blendShapeCount];

        mats = new Matrix4x4[bindPoseCount];

        for (int i = 0; i < bindPoseCount; i++)
        {
            mats[i] = ReadMatrix(reader);
        }

        for (int i = 0; i < bindPoseCount; i++)
        {
            reader.BaseStream.Seek(4, SeekOrigin.Current);
        }

        root.transform.position = Vector3.zero;
        root.transform.rotation = Quaternion.identity;
        root.transform.localScale = new Vector3(1,1,1);

        reader.BaseStream.Position = (reader.BaseStream.Position + 15) & ~15;

        for (int i = 0; i < blendShapeCount; i++)
        {
            metas[i] = new BlendShapeMeta(reader);
        }

        reader.BaseStream.Position = (reader.BaseStream.Position + 15) & ~15;

        for (int i = 0; i < blendShapeCount; i++)
        {
            datas[i] = new BlendShapeData(reader, metas[i].influencedVerts);
        }
    }

    public static Vector4 ReadVector4(BinaryReader rd)
    {
        return new Vector4(rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle());
    }

    public static Quaternion ReadQuaternion(BinaryReader rd)
    {
        return new Quaternion(rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle());
    }

    public static Matrix4x4 ReadMatrix(BinaryReader rd)
    {
        Matrix4x4 trans = new Matrix4x4(ReadVector4(rd), ReadVector4(rd), ReadVector4(rd), ReadVector4(rd));

        return trans;
    }
}

public struct Vertex
{
    public Vector3 pos;
    public Vector4 normal;
    public Vector4 tangent;
    public Color color;
    public BoneWeight skin;
    public Vector2 uv0;
    public Vector2 uv1;
    public Vector2 uv2;
    public Vector2 uv3;

    public Vertex(BinaryReader br, ChannelType[] channels, int maxvertexSize, int skinCount)
    {
        long originalPos = br.BaseStream.Position;

        int readBytes = 0;

        pos = ReadVector3(br, channels[0], ref readBytes);

        normal = ReadVector4(br, channels[1], ref readBytes);

        tangent = ReadVector4(br, channels[2], ref readBytes);

        SkipUnknown(br, channels[3]);

        color = ReadColor(br, channels[4], ref readBytes);

        SkipUnknown(br, channels[5]);
        SkipUnknown(br, channels[6]);
        SkipUnknown(br, channels[7]);

        skin = new BoneWeight();

        Vector4 indices = ReadVector4Int(br, channels[8], skinCount);
        Vector4 weights = ReadWeights(br, channels[9], ref readBytes);

        skin.boneIndex0 = (int)indices.x;
        skin.boneIndex1 = (int)indices.y;
        skin.boneIndex2 = (int)indices.z;
        skin.boneIndex3 = (int)indices.w;
        skin.weight0 = weights.x;
        skin.weight1 = weights.y;
        skin.weight2 = weights.z;
        skin.weight3 = weights.w;

        // UVs
        uv0 = ReadVector2(br, channels[10], ref readBytes);
        uv1 = ReadVector2(br, channels[11], ref readBytes);
        uv2 = ReadVector2(br, channels[12], ref readBytes);
        uv3 = ReadVector2(br, channels[13], ref readBytes);
        SkipUnknown(br, channels[14]);
        SkipUnknown(br, channels[15]);
        SkipUnknown(br, channels[16]);
        SkipUnknown(br, channels[17]);

        br.BaseStream.Position = originalPos + maxvertexSize;
    }

    public static void SkipUnknown(BinaryReader rd, ChannelType type)
    {
        if (type == ChannelType.Float)
        {
            rd.BaseStream.Position += sizeof(float);
        }
        if (type == ChannelType.FloatVector2)
        {
            rd.BaseStream.Position += 2*sizeof(float);
        }
        if (type == ChannelType.FloatVector3)
        {
            rd.BaseStream.Position += 3 * sizeof(float);
        }
        if (type == ChannelType.FloatVector4)
        {
            rd.BaseStream.Position += 4 * sizeof(float);
        }
        if (type == ChannelType.SignedShortSingle)
        {
            rd.BaseStream.Position += sizeof(short);
        }
        if (type == ChannelType.SignedShortVector4)
        {
            rd.BaseStream.Position += 4 * sizeof(short);
        }
        if (type == ChannelType.VertexColor)
        {
            rd.BaseStream.Position += 4;
        }
        if (type == ChannelType.SignedShortVector2)
        {
            rd.BaseStream.Position += 2*sizeof(short);
        }
        if (type == ChannelType.SignedShortVector3)
        {
            rd.BaseStream.Position += 3*sizeof(short);
        }
        if (type == ChannelType.SkinIndices)
        {
            rd.BaseStream.Position += 4 * sizeof(short);
        }
        if (type == ChannelType.Nothing)
        {
        }
    }

    public static float ReadMixedValue(BinaryReader rd, ChannelType type, ref int readBytes)
    {
        if (type == ChannelType.Float)
        {
            readBytes += sizeof(float);
            return rd.ReadSingle();
        }
        if (type == ChannelType.SignedShortSingle)
        {
            readBytes += sizeof(short);
            return (float)rd.ReadInt16() / 65535;
        }
        if (type == ChannelType.Nothing)
        {
            return 0;
        }
        return 0;
    }

    public static Vector2 ReadVector2(BinaryReader rd, ChannelType type, ref int readBytes)
    {
        if (type == ChannelType.FloatVector2)
        {
            readBytes += 2 * sizeof(float);
            return new Vector2(rd.ReadSingle(), rd.ReadSingle());
        }
        if (type == ChannelType.SignedShortVector2)
        {
            readBytes += 2 * sizeof(short);
            return new Vector2((float)rd.ReadInt16() / 32768, (float)rd.ReadInt16() / 32768);
        }
        if (type == ChannelType.Nothing)
        {
            return Vector2.zero;
        }
        return Vector2.zero;
    }

    public static Vector3 ReadVector3(BinaryReader rd, ChannelType type, ref int readBytes)
    {
        if (type == ChannelType.FloatVector3)
        {
            readBytes += 3 * sizeof(float);
            return new Vector3(rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle());
        }
        if (type == ChannelType.FloatVector4)
        {
            readBytes += 3 * sizeof(float);
            return new Vector4(rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle());
        }
        if (type == ChannelType.SignedShortVector4)
        {
            readBytes += 3 * sizeof(float);
            return new Vector4((float)rd.ReadInt16() / 32768, (float)rd.ReadInt16() / 32768, (float)rd.ReadInt16() / 32768, (float)rd.ReadInt16() / 32768);
        }
        if (type == ChannelType.SignedShortVector3)
        {
            readBytes += 3 * sizeof(short);
            return new Vector3((float)rd.ReadInt16() / 32768, (float)rd.ReadInt16() / 32768,(float)rd.ReadInt16() / 32768);
        }
        if (type == ChannelType.Nothing)
        {
            return Vector3.zero;
        }
        return Vector3.zero;
    }

    public static Vector4 ReadVector4(BinaryReader rd, ChannelType type, ref int readBytes)
    {
        if (type == ChannelType.SignedShortVector3)
        {
            readBytes += 3 * sizeof(short);
            return new Vector3((float)rd.ReadInt16() / 32768, (float)rd.ReadInt16() / 32768, (float)rd.ReadInt16() / 32768);
        }
        if (type == ChannelType.FloatVector3)
        {
            readBytes += 3 * sizeof(float);
            return new Vector3(rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle());
        }
        if (type == ChannelType.FloatVector4)
        {
            readBytes += 4 * sizeof(float);
            return new Vector4(rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle());
        }
        if (type == ChannelType.SignedShortVector4)
        {
            readBytes += 4 * sizeof(short);
            return new Vector4((float)rd.ReadInt16() / 32768, (float)rd.ReadInt16() / 32768, (float)rd.ReadInt16() / 32768, (float)rd.ReadInt16() / 32768);
        }
        if (type == ChannelType.VertexColor)
        {
            readBytes += 4 * sizeof(short);
            return new Vector4((float)rd.ReadInt16() / 65535, (float)rd.ReadInt16() / 65535, (float)rd.ReadInt16() / 65535, (float)rd.ReadInt16() / 65535);
        }
        if (type == ChannelType.Nothing)
        {
            return Vector4.zero;
        }
        return Vector4.zero;
    }

    public static Vector4 ReadWeights(BinaryReader rd, ChannelType type, ref int readBytes)
    {
        if (type == ChannelType.FloatVector3)
        {
            readBytes += 3 * sizeof(float);
            return new Vector3(rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle());
        }
        if (type == ChannelType.FloatVector4)
        {
            readBytes += 4 * sizeof(float);
            return new Vector4(rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle());
        }
        if (type == ChannelType.Nothing)
        {
            return new Vector4(1,0,0,0);
        }

        return Vector4.zero;
    }

    public static Vector4 ReadVector4Int(BinaryReader rd, ChannelType type, int indicesCount)
    {
        if (type == ChannelType.SkinIndices)
        {
            Vector4 indices = new Vector4(rd.ReadByte(), rd.ReadByte(), rd.ReadByte(), rd.ReadByte());

            if (indices.x != 0) indices.x = (indices.x / 3 % indicesCount);
            if (indices.y != 0) indices.y = (indices.y / 3 % indicesCount);
            if (indices.z != 0) indices.z = (indices.z / 3 % indicesCount);
            if (indices.w != 0) indices.w = (indices.w / 3 % indicesCount);

            return indices;
        }
        if (type == ChannelType.Nothing)
        {
            return Vector4.zero;
        }
        return Vector4.zero;
    }

    public static Color ReadColor(BinaryReader rd, ChannelType type, ref int readBytes)
    {
        if (type == ChannelType.VertexColor)
        {
            readBytes += 4 * sizeof(short);
            return new Color((float)rd.ReadByte() / 255, (float)rd.ReadByte()/255, (float)rd.ReadByte()/255, (float)rd.ReadByte()/ 255);
        }
        return Color.white;
    }
}

public struct BlendShapeData
{
    public string name;
    public Vector3[] aPos;
    public uint[] indices;

    public BlendShapeData(BinaryReader rd, uint influencedVerts)
    {
        name = ReadString(rd);

        aPos = new Vector3[influencedVerts];
        indices = new uint[influencedVerts];

        for (int i = 0; i < influencedVerts; i++)
        {
            aPos[i] = Read3(rd);
            indices[i] = rd.ReadUInt32();
        }
    }

    public static string ReadString(BinaryReader reader)
    {
        var result = new StringBuilder();
        char currentChar;

        while ((currentChar = reader.ReadChar()) != '\0')
        {
            result.Append(currentChar);
        }

        reader.BaseStream.Position = (reader.BaseStream.Position + 15) & ~15;

        return result.ToString();
    }

    public static Vector3 Read3(BinaryReader reader)
    {
        Vector3 vec = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
        return vec;
    }
}

public struct BlendShapeMeta
{
    public uint influencedVerts;

    public BlendShapeMeta(BinaryReader rd)
    {
        rd.BaseStream.Seek(8, SeekOrigin.Current);
        influencedVerts = rd.ReadUInt32();
        rd.BaseStream.Seek(92, SeekOrigin.Current);

        Debug.Log("influence vert: " + influencedVerts);
    }
}

public class ParseMesh : MonoBehaviour
{
    public Mesh importedMesh;
    public string srcPath;

    private Vector3 ExtractTranslation(Matrix4x4 matrix)
    {
        // Extract translation from the last column of the matrix
        Vector3 translation = new Vector3(matrix[0, 3], matrix[1, 3], matrix[2, 3]);

        return translation;
    }

    private Quaternion ExtractRotation(Matrix4x4 matrix)
    {
        Quaternion rotation = new Quaternion(matrix[3, 0], matrix[3, 1], matrix[3, 2], matrix[3, 3]);

        return rotation;
    }

    private Vector3 ExtractScale(Matrix4x4 matrix)
    {
        // Extract scale using the magnitude of basis vectors
        Vector3 scale = new Vector3(
            new Vector3(matrix[0, 0], matrix[1, 0], matrix[2, 0]).magnitude,
            new Vector3(matrix[0, 1], matrix[1, 1], matrix[2, 1]).magnitude,
            new Vector3(matrix[0, 2], matrix[1, 2], matrix[2, 2]).magnitude
        );

        return scale;
    }

    void Start()
    {
        importedMesh = new Mesh();

        BinaryReader reader = new BinaryReader(new FileStream(srcPath, FileMode.Open));
        MeshHeader header = new MeshHeader(reader, gameObject);

        Vector3[] pos = new Vector3[header.vertices.Length]; // 0
        Vector3[] normal = new Vector3[header.vertices.Length]; // 1
        Color[] color = new Color[header.vertices.Length]; // 4
        BoneWeight[] skin = new BoneWeight[header.vertices.Length]; // 8, 9
        Vector2[] uv0 = new Vector2[header.vertices.Length]; // 10
        Vector2[] uv1 = new Vector2[header.vertices.Length]; // 11
        Vector4[] tangents = new Vector4[header.vertices.Length];
        int[] faces = new int[header.uFaceCount];

        for (int i = 0; i < header.vertices.Length; i++)
        {
            pos[i] = header.vertices[i].pos;
            normal[i] = header.vertices[i].normal;
            color[i] = header.vertices[i].color;
            skin[i] = header.vertices[i].skin;
            uv0[i] = header.vertices[i].uv0;
            uv1[i] = header.vertices[i].uv1;
            tangents[i] = header.vertices[i].tangent;
        }

        for (int i = 0; i < header.faces.Length; i++)
        {
            faces[i] = (int)header.faces[i];
        }

        importedMesh.vertices = pos;
        importedMesh.normals = normal;
        importedMesh.colors = color;
        importedMesh.boneWeights = skin;
        importedMesh.uv = uv0;
        importedMesh.uv2 = uv1;
        importedMesh.triangles = faces;
        importedMesh.bindposes = header.mats;
        importedMesh.bounds = new Bounds(header.boundsPos, header.boundsSc);

        GameObject[] bones = new GameObject[header.mats.Length];

        GameObject boneRoot = GameObject.Find("skel");
        for (int i = 0; i < bones.Length; i++)
        {
            bones[i] = new GameObject("Bone_" + i);

            bones[i].transform.position = -ExtractTranslation(header.mats[i]);
            bones[i].transform.rotation = ExtractRotation(header.mats[i]);
            bones[i].transform.localScale = ExtractScale(header.mats[i]);

            Debug.Log(bones[i].transform.position);
            Debug.Log(bones[i].transform.rotation);
            Debug.Log(bones[i].transform.localScale);
            bones[i].transform.parent = boneRoot.transform;
        }

        float f = 1;

        foreach (BlendShapeData blend in header.datas)
        {
            Vector3[] deltas = new Vector3[pos.Length];
            Vector3[] blendShapeNormals = new Vector3[pos.Length];
            Vector3[] blendShapeTangents = new Vector3[pos.Length]; 

            for (int i = 0; i < blend.aPos.Length; i++)
            {
                deltas[blend.indices[i]] = blend.aPos[i];
            }

            foreach (var delta in deltas)
            {
                Debug.Log(delta);
            }

            importedMesh.AddBlendShapeFrame(blend.name, f, deltas, blendShapeNormals, blendShapeTangents);
            f += 0.0001f / header.blendShapeCount;
        }

        SkinnedMeshRenderer rende = GetComponent<SkinnedMeshRenderer>();
        rende.sharedMesh = importedMesh;
        rende.localBounds = new Bounds(importedMesh.bounds.center, importedMesh.bounds.size);
        Transform[] boners = new Transform[bones.Length];

        for (int i = 0; i < bones.Length; i++)
        {
            boners[i] = bones[i].transform;
        }

        rende.bones = boners;
        rende.rootBone = boneRoot.transform;
    }
}
