﻿using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;

public class StarliteMeshImporter : EditorWindow
{
    private string srcPath = "";

    [MenuItem("Tools/Starlite Mesh Importer")]
    public static void ShowWindow()
    {
        GetWindow<StarliteMeshImporter>("Starlite Mesh Importer");
    }

    private List<string> filePaths = new List<string>();

    private void OnGUI()
    {
        GUILayout.Label("Starlite Mesh Importer", EditorStyles.boldLabel);

        EditorGUILayout.Space();

        // Display selected file paths
        EditorGUILayout.LabelField("Selected Files:");
        foreach (string path in filePaths)
        {
            EditorGUILayout.LabelField(path);
        }

        EditorGUILayout.Space();

        // Browse Button
        if (GUILayout.Button("Browse"))
        {
            BrowseFiles();
        }

        EditorGUILayout.Space();

        // Import Button
        if (GUILayout.Button("Import"))
        {
            for (int i = 0; i < filePaths.Count; i++)
            {
                ImportMesh(filePaths[i]);
            }
        }
    }

    private void BrowseFiles()
    {
        string selectedPath = EditorUtility.OpenFilePanel("Select a Mesh File", "", "mesh,dat,bin");
        while (!string.IsNullOrEmpty(selectedPath))
        {
            if (!filePaths.Contains(selectedPath))
            {
                filePaths.Add(selectedPath);
            }
            selectedPath = EditorUtility.OpenFilePanel("Select Another Mesh File (Cancel to Finish)", "", "mesh,dat,bin");
        }
    }

    private Vector3 ExtractTranslation(Matrix4x4 matrix)
    {
        // Extract translation from the last column of the matrix
        Vector3 translation = new Vector3(-matrix[0, 3], -matrix[1, 3], -matrix[2, 3]);

        return translation;
    }

    private Quaternion ExtractRotation(Matrix4x4 matrix)
    {
        Quaternion rotation = new Quaternion(matrix[3, 0], matrix[3, 1], matrix[3, 2], matrix[3, 3]);

        return rotation;
    }

    private Vector3 ExtractScale(Matrix4x4 matrix)
    {
        // Extract scale using the magnitude of basis vectors
        Vector3 scale = new Vector3(
            new Vector3(matrix[0, 0], matrix[1, 0], matrix[2, 0]).magnitude,
            new Vector3(matrix[0, 1], matrix[1, 1], matrix[2, 1]).magnitude,
            new Vector3(matrix[0, 2], matrix[1, 2], matrix[2, 2]).magnitude
        );

        return scale;
    }

    public Mesh importedMesh;

    private void ImportMesh(string srcPath)
    {
        if (string.IsNullOrEmpty(srcPath))
        {
            EditorUtility.DisplayDialog("Error", "Please select a file before importing.", "OK");
            return;
        }

        importedMesh = new Mesh();

        GameObject gameObject = Instantiate(Resources.Load("model") as GameObject, Vector3.zero, Quaternion.identity, null);

        gameObject.name = Path.GetFileNameWithoutExtension(srcPath) + "_imported";

        BinaryReader reader = new BinaryReader(new FileStream(srcPath, FileMode.Open));
        MeshHeader header = new MeshHeader(reader, gameObject);

        Vector3[] pos = new Vector3[header.vertices.Length]; // 0
        Vector3[] normal = new Vector3[header.vertices.Length]; // 1
        Color[] color = new Color[header.vertices.Length]; // 4
        BoneWeight[] skin = new BoneWeight[header.vertices.Length]; // 8, 9
        Vector2[] uv0 = new Vector2[header.vertices.Length]; // 10
        Vector2[] uv1 = new Vector2[header.vertices.Length]; // 11
        Vector4[] tangents = new Vector4[header.vertices.Length];
        int[] faces = new int[header.uFaceCount];

        for (int i = 0; i < header.vertices.Length; i++)
        {
            pos[i] = header.vertices[i].pos;
            normal[i] = header.vertices[i].normal;
            color[i] = header.vertices[i].color;
            skin[i] = header.vertices[i].skin;
            uv0[i] = header.vertices[i].uv0;
            uv1[i] = header.vertices[i].uv1;
            tangents[i] = header.vertices[i].tangent;
        }

        for (int i = 0; i < header.faces.Length; i++)
        {
            faces[i] = (int)header.faces[i];
        }

        importedMesh.vertices = pos;
        importedMesh.normals = normal;
        importedMesh.colors = color;
        importedMesh.boneWeights = skin;
        importedMesh.uv = uv0;
        importedMesh.uv2 = uv1;
        importedMesh.triangles = faces;
        importedMesh.bindposes = header.mats;
        importedMesh.bounds = new Bounds(header.boundsPos, header.boundsSc);

        GameObject[] bones = new GameObject[header.mats.Length];

        GameObject boneRoot = gameObject.GetComponentInChildren<Skeleton>().gameObject;

        for (int i = 0; i < bones.Length; i++)
        {
            bones[i] = new GameObject("Bone_" + i);

            bones[i].transform.position = ExtractTranslation(header.mats[i]);
            bones[i].transform.rotation = ExtractRotation(header.mats[i]);
            bones[i].transform.localScale = ExtractScale(header.mats[i]);

            Debug.Log(bones[i].transform.position);
            Debug.Log(bones[i].transform.rotation);
            Debug.Log(bones[i].transform.localScale);
            bones[i].transform.parent = boneRoot.transform;
        }

        float f = 1;

        foreach (BlendShapeData blend in header.datas)
        {
            Vector3[] deltas = new Vector3[pos.Length];
            Vector3[] blendShapeNormals = new Vector3[pos.Length];
            Vector3[] blendShapeTangents = new Vector3[pos.Length];

            for (int i = 0; i < blend.aPos.Length; i++)
            {
                deltas[blend.indices[i]] = blend.aPos[i];
            }

            foreach (var delta in deltas)
            {
                Debug.Log(delta);
            }

            importedMesh.AddBlendShapeFrame(blend.name, f, deltas, blendShapeNormals, blendShapeTangents);
            f += 0.0001f / header.blendShapeCount;
        }

        SkinnedMeshRenderer rende = gameObject.GetComponentInChildren<SkinnedMeshRenderer>();
        rende.sharedMesh = importedMesh;
        rende.localBounds = new Bounds(importedMesh.bounds.center, importedMesh.bounds.size);
        Transform[] boners = new Transform[bones.Length];

        for (int i = 0; i < bones.Length; i++)
        {
            boners[i] = bones[i].transform;
        }

        rende.bones = boners;
        rende.rootBone = boneRoot.transform;

        // Placeholder for actual mesh import logic
        Debug.Log("Successfully imported mesh from: " + srcPath);
        EditorUtility.DisplayDialog("Success", "Successfully imported mesh from: " + srcPath, "OK");
    }
}
